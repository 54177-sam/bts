# CODE AUDIT - RECOMMENDED FIXES

## Quick Reference Guide for Fixing Critical Issues

---

## 🚨 CRITICAL FIX #1: Remove Authentication Bypass

**File:** `modules/dashboard.py`  
**Lines:** 348-354

### ❌ CURRENT CODE (DELETE THIS)
```python
# Login required decorator
def login_required(f):
    def decorated_function(*args, **kwargs):
        # For development, always consider logged in
        session['logged_in'] = True
        session['username'] = 'admin'
        session['role'] = 'administrator'
        return f(*args, **kwargs)
    decorated_function.__name__ = f.__name__
    return decorated_function
```

### ✅ REPLACE WITH
```python
# Use the proper decorator from auth module
from modules.auth import login_required
```

### ✅ THEN REMOVE THIS IMPORT FROM dashboard.py
```python
from modules.helpers import login_required  # DELETE THIS
```

**Impact:** Immediately secures all dashboard routes.

---

## 🚨 CRITICAL FIX #2: Fix Mock Subscriber Count

**File:** `modules/dashboard.py`  
**Lines:** 302-304

### ❌ CURRENT CODE (RETURNS RANDOM DATA)
```python
def get_subscribers_count():
    """Enhanced subscriber count with simulation"""
    import random
    return random.randint(0, 100)
```

### ✅ REPLACE WITH
```python
def get_subscribers_count():
    """Get actual subscriber count from database"""
    from modules.database import db
    return db.get_subscribers_count()
```

**Impact:** Dashboard now shows accurate subscriber count.

---

## 🚨 CRITICAL FIX #3: Move Secrets to Environment Variables

**File:** `modules/auth.py`  
**Line:** 33, 38

### ❌ CURRENT CODE (HARDCODED SECRETS)
```python
JWT_SECRET = 'siberindo-bts-jwt-secret-2024-enhanced'
JWT_ALGORITHM = 'HS256'

def hash_password(password):
    """Hash password using SHA-256 with salt"""
    salt = "siberindo-salt-2024"
    return hashlib.sha256((password + salt).encode()).hexdigest()
```

### ✅ REPLACE WITH
```python
import os
from dotenv import load_dotenv

load_dotenv()

JWT_SECRET = os.environ.get('JWT_SECRET', 'siberindo-bts-jwt-secret-2024-enhanced')
JWT_ALGORITHM = 'HS256'

def hash_password(password):
    """Hash password using SHA-256 with salt"""
    salt = os.environ.get('PASSWORD_SALT', 'siberindo-salt-2024')
    return hashlib.sha256((password + salt).encode()).hexdigest()
```

### CREATE `.env` file
```
JWT_SECRET=your-secure-random-key-here-min-32-chars
PASSWORD_SALT=another-secure-random-salt-here
SECRET_KEY=flask-session-secret-key-here
```

### UPDATE `app.py` Line 21
```python
# ❌ OLD
app.secret_key = app.config.get('SECRET_KEY', 'siberindo-bts-secret-key-2024-enhanced')

# ✅ NEW
app.secret_key = os.environ.get('SECRET_KEY', 'siberindo-bts-secret-key-2024-enhanced')
```

### UPDATE `config.py`
```python
import os
from datetime import timedelta
from dotenv import load_dotenv

load_dotenv()

class Config:
    SECRET_KEY = os.environ.get('SECRET_KEY') or 'siberindo-secret-key-2024'
    DB_PATH = os.environ.get('DB_PATH') or 'data/siberindo_bts.db'
    JWT_SECRET = os.environ.get('JWT_SECRET') or 'siberindo-bts-jwt-secret-2024-enhanced'
    # ... rest of config
```

### INSTALL python-dotenv
```bash
pip install python-dotenv
```

**Impact:** Secrets no longer exposed in source code.

---

## 🚨 CRITICAL FIX #4: Fix/Remove Missing Profile Template

**Option A: Remove the Route** (Recommended if not needed)

**File:** `modules/auth.py`  
**Lines:** 169-178

```python
# DELETE THESE LINES
@auth_bp.route('/profile')
@login_required
def profile():
    """User profile page"""
    username = session.get('username')
    user = users_db.get(username, {})
    
    profile_data = {
        'username': username,
        'full_name': user.get('full_name', ''),
        'email': user.get('email', ''),
        'role': user.get('role', ''),
        'last_login': user.get('last_login', 'Never'),
        'created_at': user.get('created_at', 'Unknown')
    }
    
    return render_template('profile.html', profile=profile_data)
```

**Option B: Create the Template** (If profile page is needed)

**File:** `templates/profile.html`

```html
{% extends "base.html" %}

{% block content %}
<div class="container mt-5">
    <div class="card">
        <div class="card-header">
            <h3>User Profile</h3>
        </div>
        <div class="card-body">
            <dl class="row">
                <dt class="col-sm-3">Username:</dt>
                <dd class="col-sm-9">{{ profile.username }}</dd>
                
                <dt class="col-sm-3">Full Name:</dt>
                <dd class="col-sm-9">{{ profile.full_name }}</dd>
                
                <dt class="col-sm-3">Email:</dt>
                <dd class="col-sm-9">{{ profile.email }}</dd>
                
                <dt class="col-sm-3">Role:</dt>
                <dd class="col-sm-9">
                    <span class="badge badge-primary">{{ profile.role }}</span>
                </dd>
                
                <dt class="col-sm-3">Last Login:</dt>
                <dd class="col-sm-9">{{ profile.last_login }}</dd>
                
                <dt class="col-sm-3">Account Created:</dt>
                <dd class="col-sm-9">{{ profile.created_at }}</dd>
            </dl>
        </div>
    </div>
</div>
{% endblock %}
```

**Impact:** Route no longer crashes with TemplateNotFound error.

---

## 🚨 CRITICAL FIX #5: Fix save_sms Parameter Mismatch

**File:** `modules/database.py`  
**Lines:** 325-326

### ❌ CURRENT CODE (WRONG PARAMETER ORDER)
```python
def save_sms(sender, receiver, message, sms_type, status='sent'):
    """Save single SMS message"""
    return db.add_sms_message(sender, receiver, message, 'sent', sms_type)
    # ↑ Parameters don't match add_sms_message signature!
```

### Check add_sms_message signature (Line 173-179)
```python
def add_sms_message(self, imsi, msisdn, message, direction, status='sent'):
    """Add SMS message to database"""
```

### ✅ CORRECT FIX
```python
def save_sms(sender, receiver, message, sms_type, status='sent'):
    """Save single SMS message"""
    # sender = IMSI, receiver = MSISDN, direction = always 'sent'
    return db.add_sms_message(sender, receiver, message, 'sent', status)
```

**Impact:** SMS messages now save correctly with proper parameters.

---

## 🟠 HIGH PRIORITY FIX #6: Consolidate login_required Decorator

**Step 1: Keep the best implementation** (from `modules/auth.py`)

The auth.py version (lines 66-82) supports both session and JWT tokens. Keep this one.

**Step 2: Remove duplicates**

Delete `login_required` from:
- `modules/helpers.py` (lines 5-10)
- `modules/dashboard.py` (lines 348-354) - Already covered in Critical Fix #1

**Step 3: Update imports**

Change all imports that use helpers or dashboard versions to:

```python
from modules.auth import login_required
```

### Update these files:
- `modules/sms_manager.py` line 2
- `modules/subscribers.py` line 2
- `modules/bts_scanner.py` line 2

**Before:**
```python
from modules.helpers import login_required
```

**After:**
```python
from modules.auth import login_required
```

---

## 🟠 HIGH PRIORITY FIX #7: Extract cache_with_timeout Decorator

**Create new file:** `modules/decorators.py`

```python
"""Shared decorators for caching and validation"""
from functools import wraps
import time


def cache_with_timeout(timeout):
    """Decorator to cache function results with timeout.
    
    Args:
        timeout: Cache expiration time in seconds
    """
    def decorator(f):
        cache = {}
        cache_time = {}
        
        @wraps(f)
        def decorated(*args, **kwargs):
            # Create cache key from arguments
            try:
                import json
                key = json.dumps((args, sorted(kwargs.items())), default=str)
            except:
                # Fallback for non-serializable args
                key = str((args, sorted(kwargs.items())))
            
            now = time.time()
            
            if key in cache and (now - cache_time[key]) < timeout:
                return cache[key]
            
            result = f(*args, **kwargs)
            cache[key] = result
            cache_time[key] = now
            return result
        
        return decorated
    return decorator
```

**Update each file** (subscribers.py, sms_manager.py, bts_scanner.py):

**Remove lines:**
```python
# DELETE THIS FUNCTION (lines vary per file)
def cache_with_timeout(timeout):
    """Decorator to cache function results with timeout."""
    def decorator(f):
        # ... entire implementation ...
```

**Add import:**
```python
from modules.decorators import cache_with_timeout
```

---

## 🟠 HIGH PRIORITY FIX #8: Fix Cache Key Hashing

The current implementation has a bug where non-hashable types (like dicts) in kwargs will cause errors.

**Location:** `modules/subscribers.py:50`, `modules/sms_manager.py:25`, `modules/bts_scanner.py:27`

### ❌ CURRENT (BUGGY)
```python
key = (args, tuple(sorted(kwargs.items())))
```

### ✅ FIXED (Use json serialization)
```python
import json
try:
    key = json.dumps((args, sorted(kwargs.items())), default=str)
except:
    key = str((args, sorted(kwargs.items())))
```

---

## 🟡 MEDIUM PRIORITY FIX #9: Add Input Validation to Routes

### Example: SMS Send Route

**File:** `modules/sms_manager.py` line 81

### ❌ CURRENT (NO VALIDATION)
```python
@sms_bp.route('/send_silent_sms', methods=['GET', 'POST'])
@login_required
def send_silent_sms():
    """Send silent SMS form and handler."""
    if request.method == 'POST':
        sender = request.form.get('sender', '').strip()
        receiver = request.form.get('receiver', '').strip()
        message = request.form.get('message', '').strip()
        # ... no validation ...
```

### ✅ WITH VALIDATION
```python
from modules.validators import DataValidator, ValidationError, validate_request_form

@sms_bp.route('/send_silent_sms', methods=['GET', 'POST'])
@login_required
def send_silent_sms():
    """Send silent SMS form and handler."""
    if request.method == 'POST':
        try:
            sender = request.form.get('sender', '').strip()
            receiver = request.form.get('receiver', '').strip()
            message = request.form.get('message', '').strip()
            
            # Validate inputs
            sender = DataValidator.validate_msisdn(sender)
            receiver = DataValidator.validate_msisdn(receiver)
            message = DataValidator.validate_string(message, min_len=1, max_len=500)
            
            # Rest of function...
        except ValidationError as e:
            return render_template('send_silent_sms.html',
                                 error=str(e),
                                 company='SIBERINDO')
        except Exception as e:
            logger.exception("Error in send_silent_sms")
            return render_template('send_silent_sms.html',
                                 error=f'Error: {str(e)}',
                                 company='SIBERINDO'), 500
```

---

## 🟡 MEDIUM PRIORITY FIX #10: Fix Parameter Mismatch in save_sms

### VERIFY and TEST

The function signature for `add_sms_message`:
```python
def add_sms_message(self, imsi, msisdn, message, direction, status='sent'):
```

But it's being called with:
```python
db.add_sms_message(sender, receiver, message, 'sent', sms_type)
```

The 4th parameter should be `status` not `sms_type`. This is a **logic error**.

### ✅ CORRECT THE MAPPING
```python
def save_sms(sender, receiver, message, sms_type, status='sent'):
    """Save single SMS message"""
    # Map parameters correctly:
    # - sender -> imsi
    # - receiver -> msisdn
    # - message -> message
    # - direction -> 'sent'
    # - status -> status (ignore sms_type here)
    return db.add_sms_message(sender, receiver, message, 'sent', status)
```

---

## 📋 IMPLEMENTATION CHECKLIST

### Phase 1: Critical Security (First)
- [ ] Delete `login_required` from dashboard.py
- [ ] Move JWT_SECRET to .env
- [ ] Move PASSWORD_SALT to .env
- [ ] Move SECRET_KEY to .env
- [ ] Fix `get_subscribers_count()` mock data
- [ ] Create/Remove profile route and template

### Phase 2: Code Quality (Next)
- [ ] Fix `save_sms()` parameter mismatch
- [ ] Consolidate `login_required` imports
- [ ] Extract `cache_with_timeout` to decorators.py
- [ ] Fix cache key serialization

### Phase 3: Refactoring (Then)
- [ ] Extract pagination logic
- [ ] Optimize service status queries
- [ ] Add input validation to routes
- [ ] Remove unused imports

### Phase 4: Improvements (Finally)
- [ ] Add CSRF protection (Flask-WTF)
- [ ] Improve password hashing (bcrypt)
- [ ] Add comprehensive logging
- [ ] Increase test coverage

---

## 🧪 TESTING CHECKLIST

After applying fixes:

- [ ] Run `pytest tests/test_suite.py` - All tests pass
- [ ] Test login with wrong credentials - Should fail
- [ ] Test protected routes without login - Should redirect
- [ ] Test SMS sending - Should save to database
- [ ] Test subscriber count - Should show actual count (not random)
- [ ] Visit /auth/profile - Should load or 404 (not 500)
- [ ] Check for any hardcoded strings - Should use config

---

## ⏱️ TIME ESTIMATES

| Fix | Complexity | Time |
|-----|-----------|------|
| Remove dashboard login_required | Simple | 5 min |
| Fix subscriber count | Simple | 5 min |
| Move secrets to env | Medium | 20 min |
| Create/Remove profile | Simple | 10 min |
| Fix save_sms | Simple | 10 min |
| Consolidate login_required | Medium | 30 min |
| Extract cache_with_timeout | Medium | 20 min |
| Fix cache keys | Simple | 10 min |
| Add input validation | Medium | 30 min |
| **TOTAL** | **Medium** | **2.5 hours** |

---

## 📚 RELATED FILES TO REVIEW

After applying these fixes, review:
1. `requirements.txt` - Ensure all dependencies listed
2. `.gitignore` - Ensure .env is ignored
3. `README.md` - Update setup instructions for .env
4. `CHANGELOG.md` - Document fixes applied
5. `docker-compose.yml` - Update if using environment variables

---

*Generated: November 27, 2024*
*For the complete audit report, see CODE_AUDIT_REPORT.json*
