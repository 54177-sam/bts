#!/bin/bash
# Start script for SIBERINDO BTS GUI

# Activate virtual environment
source siberindo-venv/bin/activate

# Run application
python3 run.py